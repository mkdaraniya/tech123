<?php
 
\Magento\Framework\Component\ComponentRegistrar::register(
 \Magento\Framework\Component\ComponentRegistrar::MODULE,
 'RSCoder_DuplicateEntry',
 __DIR__
);